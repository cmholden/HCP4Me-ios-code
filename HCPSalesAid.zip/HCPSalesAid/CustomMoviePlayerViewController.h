//
//  CustomMoviePlayerViewController.h
//  HCPSalesAid
//
//  Created by cmholden on 02/07/2015.
//  Copyright (c) 2015 cmholden. All rights reserved.
//

#import <MediaPlayer/MediaPlayer.h>

@interface CustomMoviePlayerViewController : MPMoviePlayerViewController

@end
