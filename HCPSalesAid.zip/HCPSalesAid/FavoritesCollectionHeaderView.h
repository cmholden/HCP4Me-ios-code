//
//  FavoritesCollectionHeaderView.h
//  HCPSalesAid
//
//  Created by cmholden on 07/07/2015.
//  Copyright (c) 2015 cmholden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesCollectionHeaderView : UICollectionReusableView

@end
