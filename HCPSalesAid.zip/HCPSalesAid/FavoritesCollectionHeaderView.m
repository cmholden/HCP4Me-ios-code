//
//  FavoritesCollectionHeaderView.m
//  HCPSalesAid
//
//  Created by cmholden on 07/07/2015.
//  Copyright (c) 2015 cmholden. All rights reserved.
//

#import "FavoritesCollectionHeaderView.h"

@implementation FavoritesCollectionHeaderView

@end
