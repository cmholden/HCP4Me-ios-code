//
//  AssetsCollectionFooterView.h
//  HCPSalesAid
//
//  Created by cmholden on 01/07/2015.
//  Copyright (c) 2015 cmholden. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssetsCollectionFooterView : UICollectionReusableView

@end
