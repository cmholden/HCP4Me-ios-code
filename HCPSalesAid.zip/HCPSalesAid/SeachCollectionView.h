//
//  SeachCollectionView.h
//  HCPSalesAid
//
//  Created by cmholden on 02/07/2015.
//  Copyright (c) 2015 cmholden. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "AssetsCollectionView.h"
#import "UserAssetStatus.h"

@interface SeachCollectionView : AssetsCollectionView

@end
