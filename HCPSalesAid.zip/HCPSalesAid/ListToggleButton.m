//
//  ListToggleButton.m
//  HCPSalesAid
//
//  Created by cmholden on 01/07/2015.
//  Copyright (c) 2015 cmholden. All rights reserved.
//

#import "ListToggleButton.h"

@implementation ListToggleButton

@synthesize sectionNum;
@synthesize headerView;

@end
